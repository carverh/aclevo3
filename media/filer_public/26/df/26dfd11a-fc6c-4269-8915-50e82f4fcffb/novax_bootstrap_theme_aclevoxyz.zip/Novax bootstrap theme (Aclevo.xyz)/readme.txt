Thanks for downloading this theme!

This theme is public domain.
You may copy and redistribute this theme, with or without attribution, for commercial as well as non-commercial purposes. However, you may not apply legal terms or technological measures that legally restrict others from doing anything this license permits. 

This theme is provided “as-is” and comes with ABSOLUTELY NO WARRANTY expressed or implied.

Theme name: Novax
Theme URL: 
Published by: Aclevo.xyz
Author: RXdesign
